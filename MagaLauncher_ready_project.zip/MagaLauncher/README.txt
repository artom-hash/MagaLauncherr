MAGA RUSSIA Launcher — source project

FTP settings in app/src/main/java/ru/magarussia/launcher/Config.kt
Host: 5.187.181.57 | Port: 21 | Protocol: plain FTP (PASV)
Set FTP_USER and FTP_PASSWORD before use. FTP is not encrypted; do not use sensitive/reused passwords.

FTP layout expected under FTP_ROOT (default /launcher):
  servers.json  JSON array: [{"name":"Server 1","ip":"127.0.0.1","port":8021}]
  manifest.json JSON array: [{"path":"relative/path","size":123,"sha256":"64 hex chars"}]
  files/       mirror of manifest paths

The launcher downloads files into Android app external files/cache. It does NOT install arbitrary game APKs,
modify protected game data, or guarantee client launch integration. Set GAME_PACKAGE to the actual package.

Open project in Android Studio, sync Gradle, build APK. This source has not been built/tested in an Android SDK environment.
