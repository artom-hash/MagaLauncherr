package ru.magarussia.launcher

/** FTP configuration. FTP is unencrypted: do not use a password reused elsewhere. */
object Config {
    const val FTP_HOST = "5.187.181.57"
    const val FTP_PORT = 21
    const val FTP_USER = "CHANGE_ME"
    const val FTP_PASSWORD = "CHANGE_ME"
    const val FTP_ROOT = "/launcher" // expects servers.json, manifest.json and files/ below this root
    const val GAME_PACKAGE = "ru.magarussia.game" // replace with the actual game package
}
