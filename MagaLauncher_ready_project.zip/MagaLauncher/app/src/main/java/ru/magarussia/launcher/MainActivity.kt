package ru.magarussia.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Accent = Color(0xFFFF4778)
private val Accent2 = Color(0xFFFFA24A)
private val Panel = Color(0xFF171923)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Color(0xFF090B12))) { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val updater = remember { Updater(ctx) }
    val prefs = remember { ctx.getSharedPreferences("main", 0) }
    var servers by remember { mutableStateOf(listOf<Server>()) }
    var sel by remember { mutableIntStateOf(0) }
    var nick by remember { mutableStateOf(prefs.getString("nick", "") ?: "") }
    var todo by remember { mutableStateOf(listOf<RemoteFile>()) }
    var status by remember { mutableStateOf("Подключение к серверу…") }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(true) }
    var loaded by remember { mutableStateOf(false) }

    suspend fun refresh() {
        busy = true
        try {
            servers = fetchServers()
            sel = sel.coerceIn(0, (servers.size - 1).coerceAtLeast(0))
            todo = updater.outdated(updater.fetchManifest())
            progress = if (todo.isEmpty()) 1f else 0f
            status = if (todo.isEmpty()) "Клиент готов к запуску" else "Доступно обновление · ${todo.sumOf { it.size } / 1048576} МБ"
            loaded = true
        } catch (e: Exception) {
            status = "Не удалось проверить файлы: ${e.localizedMessage ?: "ошибка сети"}"
        } finally { busy = false }
    }
    LaunchedEffect(Unit) { refresh() }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF080A11), Color(0xFF171020), Color(0xFF291323)))).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MAGA", fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp,
                        color = Color.White)
                    Text("RUSSIA", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp,
                        color = Accent2)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0x2222CC88)) {
                    Text("●  ONLINE", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Color(0xFF69DDAA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(24.dp))
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = Panel, border = BorderStroke(1.dp, Color(0x22FFFFFF))) {
                Column(Modifier.padding(18.dp)) {
                    Text("ВЫБЕРИ СЕРВЕР", fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB7B8C5))
                    Spacer(Modifier.height(12.dp))
                    if (servers.isEmpty()) {
                        Text(if (loaded) "Список серверов пуст" else "Загружаем список…", color = Color.White)
                    } else {
                        LazyColumn(Modifier.heightIn(max = 230.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            itemsIndexed(servers) { i, s -> ServerCard(s, i == sel) { sel = i } }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(value = nick, onValueChange = { nick = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(20) },
                label = { Text("Игровой ник") }, placeholder = { Text("Имя_Фамилия") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color(0x44FFFFFF)))
            Spacer(Modifier.weight(1f))
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), color = Color(0xFF11131B), border = BorderStroke(1.dp, Color(0x22FFFFFF))) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("СОСТОЯНИЕ", fontSize = 11.sp, letterSpacing = 1.5.sp, color = Color(0xFFB7B8C5), modifier = Modifier.weight(1f))
                        TextButton(enabled = !busy, onClick = { scope.launch { refresh() } }) { Text("ПРОВЕРИТЬ") }
                    }
                    Text(status, fontSize = 13.sp, color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { progress.coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(10.dp)), color = Accent, trackColor = Color(0x22FFFFFF))
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(enabled = !busy && (servers.isNotEmpty() || todo.isNotEmpty()), onClick = {
                scope.launch {
                    if (todo.isNotEmpty()) {
                        busy = true; progress = 0f
                        try {
                            updater.download(todo) { d, t ->
                                progress = if (t > 0) (d.toFloat()/t).coerceIn(0f,1f) else 0f
                                status = "Загрузка файлов · ${d / 1048576} / ${t / 1048576} МБ"
                            }
                            status = "Файлы обновлены"
                        } catch (e: Exception) { status = "Ошибка загрузки: ${e.localizedMessage ?: "ошибка"}" }
                        refresh()
                    } else if (nick.length < 3) status = "Ник должен содержать минимум 3 символа"
                    else if (servers.isNotEmpty()) {
                        prefs.edit().putString("nick", nick).apply()
                        if (!launchGame(ctx, servers[sel], nick)) status = "Игровой клиент не найден. Установите игру."
                    }
                }
            }, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, disabledContainerColor = Color(0xFF44444D))) {
                Text(if (busy) "ПОДОЖДИТЕ…" else if (todo.isNotEmpty()) "СКАЧАТЬ ОБНОВЛЕНИЕ" else "ИГРАТЬ", fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text("MAGA RUSSIA  •  unofficial launcher", Modifier.fillMaxWidth(), color = Color(0x66FFFFFF), fontSize = 10.sp)
        }
    }
}

@Composable
fun ServerCard(s: Server, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(15.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(if (selected) Color(0x22FF4778) else Color(0xFF20222B))
        .border(BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) Accent else Color(0x22FFFFFF)), shape)
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(s.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("${s.ip}:${s.port}", color = Color(0x99FFFFFF), fontSize = 12.sp)
        }
        Text(if (selected) "✓" else "›", color = if (selected) Accent else Color(0x66FFFFFF), fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}
