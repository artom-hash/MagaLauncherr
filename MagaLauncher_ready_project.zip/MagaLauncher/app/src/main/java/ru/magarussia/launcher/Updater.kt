package ru.magarussia.launcher

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.*
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.json.JSONArray
import java.io.*
import java.security.MessageDigest

data class RemoteFile(val path: String, val size: Long, val sha256: String)
data class Server(val name: String, val ip: String, val port: Int)

private fun ftp(block: (FTPClient) -> Unit) {
    val client = FTPClient()
    client.connectTimeout = 10000; client.defaultTimeout = 10000; client.dataTimeout = 15000
    try {
        client.connect(Config.FTP_HOST, Config.FTP_PORT)
        if (!client.login(Config.FTP_USER, Config.FTP_PASSWORD)) throw IOException("FTP login failed")
        client.enterLocalPassiveMode(); client.setFileType(FTP.BINARY_FILE_TYPE)
        block(client)
    } finally { if (client.isConnected) { try { client.logout() } finally { client.disconnect() } } }
}
private fun readRemote(path: String): String = ftp { c ->
    val stream = c.retrieveFileStream(path) ?: throw IOException("FTP file not found: $path")
    val content = stream.bufferedReader().use { it.readText() }
    if (!c.completePendingCommand()) throw IOException("FTP transfer incomplete")
    return content
}

suspend fun fetchServers(): List<Server> = withContext(Dispatchers.IO) {
    val a = JSONArray(readRemote(Config.FTP_ROOT + "/servers.json"))
    List(a.length()) { a.getJSONObject(it).let { o -> Server(o.getString("name"), o.getString("ip"), o.getInt("port")) } }
}

fun launchGame(ctx: Context, s: Server, nick: String): Boolean {
    val i: Intent = ctx.packageManager.getLaunchIntentForPackage(Config.GAME_PACKAGE) ?: return false
    i.putExtra("ip", s.ip).putExtra("port", s.port).putExtra("nickname", nick)
    ctx.startActivity(i); return true
}

class Updater(ctx: Context) {
    private val root = File(ctx.getExternalFilesDir(null), "cache").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("hashes", Context.MODE_PRIVATE)
    suspend fun fetchManifest(): List<RemoteFile> = withContext(Dispatchers.IO) {
        val a = JSONArray(readRemote(Config.FTP_ROOT + "/manifest.json"))
        List(a.length()) { a.getJSONObject(it).let { o ->
            val path=o.getString("path")
            if (path.isBlank() || path.startsWith("/") || path.split("/").any { it==".." } || path.contains("\\")) throw IOException("Invalid manifest path")
            RemoteFile(path,o.getLong("size"),o.getString("sha256"))
        } }
    }
    private fun hash(f: File): String { val md=MessageDigest.getInstance("SHA-256"); f.inputStream().use { s -> val b=ByteArray(65536); while(true){val n=s.read(b);if(n<0)break;md.update(b,0,n)} }; return md.digest().joinToString(""){"%02x".format(it)} }
    private fun key(f: File)="${f.path}|${f.length()}|${f.lastModified()}"
    private fun cachedHash(f: File)=prefs.getString(key(f),null) ?: hash(f).also { prefs.edit().putString(key(f),it).apply() }
    suspend fun outdated(list: List<RemoteFile>): List<RemoteFile> = withContext(Dispatchers.IO) { list.filter { val f=File(root,it.path); !f.exists() || f.length()!=it.size || cachedHash(f)!=it.sha256 } }
    suspend fun download(files: List<RemoteFile>, onProgress: (Long,Long)->Unit)=withContext(Dispatchers.IO) {
        val total=files.sumOf{it.size}; var done=0L
        for (rf in files) {
            ensureActive(); val dst=File(root,rf.path); dst.parentFile?.mkdirs(); val part=File(dst.path+".part")
            if(part.exists() && part.length()>rf.size) part.delete(); var have=if(part.exists())part.length() else 0L
            if(have>=rf.size && hash(part)==rf.sha256){done+=have;dst.delete();part.renameTo(dst);continue}
            if(have>0) part.delete(); have=0
            ftp { c ->
                val remote=Config.FTP_ROOT+"/files/"+rf.path
                val stream=c.retrieveFileStream(remote) ?: throw IOException("Missing FTP file: $remote")
                FileOutputStream(part).use { out -> stream.use { input -> val b=ByteArray(65536); while(true){ensureActive();val n=input.read(b);if(n<0)break;out.write(b,0,n);done+=n;onProgress(done,total)} } }
                if(!c.completePendingCommand()) throw IOException("FTP transfer incomplete: ${rf.path}")
            }
            if(part.length()!=rf.size || hash(part)!=rf.sha256){part.delete();throw IOException("Integrity check failed: ${rf.path}")}
            dst.delete(); if(!part.renameTo(dst)) throw IOException("Could not finalize file: ${rf.path}"); prefs.edit().putString(key(dst),rf.sha256).apply()
        }
    }
}
