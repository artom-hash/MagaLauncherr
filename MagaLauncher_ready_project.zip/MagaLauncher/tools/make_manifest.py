"""Запуск: python make_manifest.py путь_к_папке_кэша
Создаёт manifest.json (путь, размер, sha256) в этой папке. Запускать после каждого изменения кэша, затем залить папку на хост."""
import hashlib, json, os, sys
root = sys.argv[1]
out = []
for d, _, fs in os.walk(root):
    for f in sorted(fs):
        if f == "manifest.json": continue
        p = os.path.join(d, f); h = hashlib.sha256()
        with open(p, "rb") as fh:
            for b in iter(lambda: fh.read(1 << 20), b""): h.update(b)
        out.append({"path": os.path.relpath(p, root).replace(os.sep, "/"), "size": os.path.getsize(p), "sha256": h.hexdigest()})
json.dump(out, open(os.path.join(root, "manifest.json"), "w"), indent=1)
print(len(out), "файлов в manifest.json")
